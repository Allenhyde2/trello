
  # Trello Style Kanban App (Community)

  This is a code bundle for Trello Style Kanban App (Community). The original project is available at https://www.figma.com/design/pJhUlkhnlYzofczLkPPMlV/Trello-Style-Kanban-App--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  